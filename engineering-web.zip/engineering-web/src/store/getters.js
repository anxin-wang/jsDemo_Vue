export const rootUrl = state => {
  return state.rootUrl
}

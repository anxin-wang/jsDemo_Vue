<template>
  <div class="grzx_right grzx_right_b">
    <div class="grzx_right1 grzx_right1_b">
    </div>

  </div>
</template>

<script>
  export default {
    name: 'user_resources',
    data () {
      return {
      }
    }
  }
</script>

<style>
</style>

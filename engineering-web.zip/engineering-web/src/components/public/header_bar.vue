<template>
  <div class="top_bg">
    <div class="top">
      <div class="top_login">
        <a href="" class="login_btn">登陆</a>
        <a href="" class="reg_btn">注册</a>
      </div>
      <div class="home">
        <a href="">首页</a>|
        <a href="">关于我们</a>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'header_bar',
    data () {
      return {
      }
    }
  }
</script>

<style>
</style>

<template>
  <div class="footer_bg">
    <p>Copyright @2017 Tongjl.All Rights Reserved.<br>
      同济大学出版祉版权所有 上海市杨浦区赤峰路2号 021-0000000</p>
  </div>
</template>

<script>
  export default {
    name: 'footer_bar',
    data () {
      return {
      }
    }
  }
</script>

<style>
</style>

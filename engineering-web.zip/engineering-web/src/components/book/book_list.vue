<template>
  <div class="bg">
    <header-bar></header-bar>
    <div class="clear"></div>
    <search-bar></search-bar>
    <div class="clear"></div>
    <div class="list_main">
      <div class="main_left">
        <div class="list_left">
          <div class="class_title"><span>所有类别</span></div>
          <div class="list_class">
            <div class="list_title">
              <p>分类一</p>
              <span><img src="../../assets/images/jian.png" alt=""></span>
            </div>
            <ul>
              <li><em>213</em><a href="">小分类一</a></li>
              <li><em>213</em><a href="">小分类一</a></li>
              <li><em>213</em><a href="">小分类一</a></li>
              <li><em>213</em><a href="">小分类一</a></li>
            </ul>
          </div>
          <div class="list_class">
            <div class="list_title">
              <p>分类二</p>
              <span><img src="../../assets/images/jian.png" alt=""></span>
            </div>
            <ul>
              <li><em>213</em><a href="">小分类二</a></li>
              <li><em>213</em><a href="">小分类二</a></li>
              <li><em>213</em><a href="">小分类二</a></li>
              <li><em>213</em><a href="">小分类二</a></li>
            </ul>
          </div>
          <div class="list_class">
            <div class="list_title">
              <p>分类三</p>
              <span><img src="../../assets/images/jia.png" alt=""></span>
            </div>
            <ul class="dn">
              <li><em>213</em><a href="">小分类三</a></li>
              <li><em>213</em><a href="">小分类三</a></li>
              <li><em>213</em><a href="">小分类三</a></li>
              <li><em>213</em><a href="">小分类三</a></li>
            </ul>
          </div>
          <div class="list_class">
            <div class="list_title">
              <p>分类四</p>
              <span><img src="../../assets/images/jian.png" alt=""></span>
            </div>
            <ul>
              <li><em>213</em><a href="">小分类四</a></li>
              <li><em>213</em><a href="">小分类四</a></li>
              <li><em>213</em><a href="">小分类四</a></li>
              <li><em>213</em><a href="">小分类四</a></li>
            </ul>
          </div>
        </div>
        <div class="list_cent">
          <div class="list_list">
            <div class="list_cout">已为您 找到"<font color="#4a91e3">中文</font>"相关结果约100，000，000个，用时0.030秒</div>
            <div class="list_li">
              <dl>
                <dt><img src="../../assets/images/img.jpg" alt=""></dt>
                <dd>
                  <em>图书</em><p><a href="">注册与登陆设计备忘</a></p>
                  <div class="clear"></div>
                  <span>本文为网易云课堂--运营微专来的课程作业，如有疑问，欢迎交流。任选一互联网产品，策划一期活动，撰写出活动方案。一，活动背景常规节日活动，六一儿童节。二活动目的获....</span>
                  <a class="fav"><small></small><span>已加收藏夹</span></a>
                </dd>
              </dl>
              <dl>
                <dt><img src="../../assets/images/img.jpg" alt=""></dt>
                <dd>
                  <em>图书</em><p><a href="">注册与登陆设计备忘</a></p>
                  <div class="clear"></div>
                  <span>本文为网易云课堂--运营微专来的课程作业，如有疑问，欢迎交流。任选一互联网产品，策划一期活动，撰写出活动方案。一，活动背景常规节日活动，六一儿童节。二活动目的获....</span>
                  <a class="fav"><small></small><span>已加收藏夹</span></a>
                </dd>
              </dl>
              <dl>
                <dt><img src="../../assets/images/img.jpg" alt=""></dt>
                <dd>
                  <em>图书</em><p><a href="">注册与登陆设计备忘</a></p>
                  <div class="clear"></div>
                  <span>本文为网易云课堂--运营微专来的课程作业，如有疑问，欢迎交流。任选一互联网产品，策划一期活动，撰写出活动方案。一，活动背景常规节日活动，六一儿童节。二活动目的获....</span>
                  <a class="fav"><small></small><span>已加收藏夹</span></a>
                </dd>
              </dl>
              <dl>
                <dt><img src="../../assets/images/img.jpg" alt=""></dt>
                <dd>
                  <em>图书</em><p><a href="">注册与登陆设计备忘</a></p>
                  <div class="clear"></div>
                  <span>本文为网易云课堂--运营微专来的课程作业，如有疑问，欢迎交流。任选一互联网产品，策划一期活动，撰写出活动方案。一，活动背景常规节日活动，六一儿童节。二活动目的获....</span>
                  <a class="fav"><small></small><span>已加收藏夹</span></a>
                </dd>
              </dl>
              <dl>
                <dt><img src="../../assets/images/img.jpg" alt=""></dt>
                <dd>
                  <em>图书</em><p><a href="">注册与登陆设计备忘</a></p>
                  <div class="clear"></div>
                  <span>本文为网易云课堂--运营微专来的课程作业，如有疑问，欢迎交流。任选一互联网产品，策划一期活动，撰写出活动方案。一，活动背景常规节日活动，六一儿童节。二活动目的获....</span>
                  <a class="fav"><small></small><span>已加收藏夹</span></a>
                </dd>
              </dl>
              <dl>
                <dt><img src="../../assets/images/img.jpg" alt=""></dt>
                <dd>
                  <em>图书</em><p><a href="">注册与登陆设计备忘</a></p>
                  <div class="clear"></div>
                  <span>本文为网易云课堂--运营微专来的课程作业，如有疑问，欢迎交流。任选一互联网产品，策划一期活动，撰写出活动方案。一，活动背景常规节日活动，六一儿童节。二活动目的获....</span>
                  <a class="fav"><small></small><span>已加收藏夹</span></a>
                </dd>
              </dl>
            </div>
            <div class="clear"></div>
            <div class="list_page">
              <a href="" class="page_cur">1</a>
              <a href="">2</a>
              <a href="">3</a>
              <a href="">4</a>
              <a href="">5</a>
              <a href="">></a>
            </div>
          </div>

        </div>

      </div>
      <div class="list_right">
        <a href=""><img src="../../assets/images/img1.jpg" alt=""></a>
        <a href=""><img src="../../assets/images/img1.jpg" alt=""></a>
      </div>
    </div>
    <div class="clear"></div>
    <footer-bar></footer-bar>
  </div>
</template>

<script>
  import headerBar from '../public/header_bar.vue'
  import footerBar from '../public/footer_bar.vue'
  import searchBar from '../public/search_bar.vue'
  export default {
    name: 'book_list',
    data () {
      return {
      }
    },
    components: {
      headerBar,
      footerBar,
      searchBar
    }
  }
</script>

<style>
</style>

<template>
  <router-view></router-view>
</template>

<script>
import menus from '@/components/Menu.vue'
import heads from '@/components/Header.vue'
export default {
  data () {
    return {
    }
  }
}
</script>

<style scoped>

</style>
